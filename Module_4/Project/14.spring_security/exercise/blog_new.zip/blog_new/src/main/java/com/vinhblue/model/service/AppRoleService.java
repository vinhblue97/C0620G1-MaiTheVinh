package com.vinhblue.model.service;

import com.vinhblue.model.entity.AppRole;

import java.util.List;

public interface AppRoleService {
    List<AppRole> findAll();
}
