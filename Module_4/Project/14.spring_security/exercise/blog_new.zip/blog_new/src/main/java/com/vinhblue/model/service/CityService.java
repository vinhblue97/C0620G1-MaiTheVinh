package com.vinhblue.model.service;

import com.vinhblue.model.entity.CityManagement;

import java.util.List;

public interface CityService {
    List<CityManagement> findAll();
}
